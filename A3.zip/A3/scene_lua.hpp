#pragma once

#include <string>
#include "SceneNode.hpp"

SceneNode * import_lua(const std::string & filename);

